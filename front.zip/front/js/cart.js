
// on initialise notre panier en tant que tableau
const cart = [];
//on déclare notre fonction
cartArticle();
console.log(cart);

//on a récupéré nos élement et on les a mis dans 'cart'
function cartArticle() {
  const numberOfItems = localStorage.length;
  for (let i = 0; i < numberOfItems; i++) {
    //item est une string et on veut un objet
    const item = localStorage.getItem(localStorage.key(i));
    //on le transforme donc en objet avec JSON.parse
    const itemObject = JSON.parse(item);
    cart.push(itemObject);
  }
  
}
 saveCart =  JSON.parse(localStorage.getItem("cartArticle"));
//Ensuite pour chaque élément dans cart on vas créer les élements du html en js
let cartItems = document.getElementById("#cart__items");
let cartItemImg = document.getElementById("cart__item__img");

           //fetch récupèrer détails produits qui ne sont pas dans le LocalStorage
           for(let cartArticle in saveCart){
          
            //fetch récupèrer détails produits qui ne sont pas dans le LocalStorage
              fetch('http://localhost:3000/api/products/' + saveCart[cartArticle].id)
                 .then((res) => res.json())
                 .then((promise) => {
                 console.log(promise)
 
             //création article
             let cartItem = document.createElement("article");
             cartItem.className = "cart__item";
             cartItem.setAttribute('data-color', articleData.color);
 
                 //image
                 cartItemImg = document.createElement("div");
                 cartItemImg.className = ("cart__item__img");
                 cartItemImg.appendChild(containDivImg);
                     
                     let img = document.createElement("img");
                     cartItemImg.appendChild(img);
                         img.src = cartArticle.imageUrl;
                         img.alt = cartArticle.altTxt;
           })
           }
