//grace a window.location.href on affiche l'id du bon élément sur la page produit
let string = window.location.href;
var url = new URL(string);
let idProduct = url.searchParams.get("id");
console.log(idProduct);

const chosenColor = document.getElementById("colors");
//Ensuite on récupère les donées de l'Api
fetch("http://localhost:3000/api/products/" + idProduct)
  .then((res) => res.json())
  .then((article) => {
    console.log(article);
    console.log(article.name);
    console.log(article.description);

    let name = article.name;
    let description = article.description;
    let price = article.price;

    let nameHtml = document.getElementById("title");
    nameHtml.textContent = name;
    let descriptionHtml = document.getElementById("description");
    descriptionHtml.textContent = description;
    let priceHtml = document.getElementById("price");
    priceHtml.textContent = price;

    let productImg = document.createElement("img");
    document.getElementsByClassName("item__img")[0].appendChild(productImg);
    productImg.src = article.imageUrl;
    productImg.alt = article.altTxt;

    for (let color of article.colors) {
      console.log(color);
      let productColor = document.createElement("option");
      productColor.value = color;
      productColor.textContent = color;
      chosenColor.appendChild(productColor);
      
    }
 
  

  // btn_sendCart.addEventListener("click", (event)=> { 
  // event.preventDefault()
  // let btn_sendCart = document.getElementById("addToCart");
  // console.log(btn_sendCart)

// on utilise add event listener pour écouter un élément (click/scroll/touche du clavier etc ...)
// en locurence ici on écoute notre panier pour savoir quel article doit etre chargé puis récupéré

//on crée notre objet avec nos informations concernant le produit


// let cartArticle = {
//   id: "107fb5b75607497b96722bda5b504926", 
//   color: "White",
//   quantity: ""
// }


// //On déclare notre objet dans le localStorage en indiquant son nom de clé, l'id et sa couleur. Ensuite on séréalise et on transforme nos données en chaine de caractère grace a JSON.stringify
// localStorage.setItem( "sinope" + cartArticle.id + "_" + cartArticle.color, JSON.stringify(cartArticle))

// //On modifie nos données du
// let sinopeBlack = JSON.parse(localStorage.getItem("107fb5b75607497b96722bda5b504926_Black"))
// sinopeBlack.quantity += 5
// localStorage.setItem( sinopeBlack.id + sinopeBlack.color, JSON.stringify(sinopeBlack))

// let sinopeBlue = JSON.parse(localStorage.getItem("107fb5b75607497b96722bda5b504926_Blue"))
// sinopeBlue.quantity += 1
// localStorage.setItem( sinopeBlue.id + sinopeBlue.color, JSON.stringify(sinopeBlue))

// let sinopeWhite = JSON.parse(localStorage.getItem("107fb5b75607497b96722bda5b504926_White"))
// sinopeWhite.quantity += 20
// localStorage.setItem( sinopeWhite.id + sinopeWhite.color, JSON.stringify(sinopeWhite))


//  let cartArticle2 = {
//    id: "415b7cacb65d43b2b5c1ff70f3393ad1",
//    color: "Black/Yellow",
//    quantity: ""
//  }
// // //on va chercher notre id plus notre couleur de larticle2 en utilisant JSON.stringify
// localStorage.setItem("cyllene" + cartArticle2.id + "_" + cartArticle2.color, JSON.stringify(cartArticle2))


// // //on modifie le contenu de blibliRED
//   let cylleneBlackYellow = JSON.parse(localStorage.getItem("415b7cacb65d43b2b5c1ff70f3393ad1_Black/Yellow"))
// cylleneBlackYellow.quantity += "2"
//   localStorage.setItem(cylleneBlackYellow.id + cylleneBlackYellow.color, JSON.stringify(cylleneBlackYellow))

//   let cartArticle3 = {
//     id: "055743915a544fde83cfdfc904935ee7",
//     color: "Green",
//     quantity: "1"
//   }
//   localStorage.setItem("calyce" + cartArticle3.id + "_" + cartArticle3.color, JSON.stringify(cartArticle3))

//   let calyceGreen = JSON.parse(localStorage.getItem("415b7cacb65d43b2b5c1ff70f3393ad1_Green"))
//   calyceGreen.quantity += "2"
//     localStorage.setItem(calyceGreen.id + calyceGreen.color, JSON.stringify(calyceGreen))


// let optionsProduit = {
//   imgProduit: article.imageUrl,
//   altImgProduit: article.altTxt,
//   idProduit: idProduct,
//   quantiteProduit: Number(quantity),
//   nomProduit: name,
//   prixProduit: "",
//   couleurProduit: chosenColor,
//   descriptionProduit: description,
// };

// let productSaveLocalStorage = JSON.parse(localStorage.getItem("produit"));
// console.log(productSaveLocalStorage);

// // });

// if (productSaveLocalStorage) {
// } else
//   () => {
//     productSaveLocalStorage = [];
//     productSaveLocalStorage.push(optionsProduit);
//     console.log(productSaveLocalStorage);
//   };


});

//le formulaire s'adapte au nombre d'options qu'il y a dans l'objet du produit


const button = document.getElementById("addToCart")
if (button != null){
button.addEventListener("click", (e) => {
  //on ajoute nos éléments à écouter
 const color = document.getElementById("colors").value
 const quantity = document.getElementById("quantity").value
 // on paramètre les propriétés d'utilisateur, si couleur est nulle ou couleur = 0 et si quanitity = null ou 0 on retourne un message derreur 
 if (color == null || color == "" || quantity == null || quantity == 0){
  alert("Please select the color and the quantity")
 }

 let cartArticle = {
   id: "107fb5b75607497b96722bda5b504926", //j'ai essayé de mettre id : id, comme id mais la console me dit qu'il nest pas défini  
   color: color,
   quantity: quantity
 }
localStorage.setItem("kanape", JSON.stringify(cartArticle))

})

}
